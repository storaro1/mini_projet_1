document.addEventListener("DOMContentLoaded", function() {
  const cocktailElement = document.getElementById("cocktail");
  cocktailElement.textContent = "Long Island Iced Tea";
});
