

const a = prompt("entrez la valeur de a");
const b = prompt("entrez la valeur de b");

const result = parseInt(a) + parseInt(b);

console.log(result)

alert("Le résultat de la somme est : " + result);